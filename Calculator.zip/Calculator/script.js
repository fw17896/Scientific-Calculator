const display = document.getElementById('display');
const result = document.getElementById('result');

// Mapping of visible functions to JavaScript equivalents
const functionMap = {
  'sin': 'Math.sin',
  'cos': 'Math.cos',
  'tan': 'Math.tan',
  'log': 'Math.log10',
  '√': 'Math.sqrt',
  'π': 'Math.PI',
  '^': '**'
};

function append(value) {
  if (value === 'Math.sin(') display.value += 'sin(';
  else if (value === 'Math.cos(') display.value += 'cos(';
  else if (value === 'Math.tan(') display.value += 'tan(';
  else if (value === 'Math.log10(') display.value += 'log(';
  else if (value === 'Math.sqrt(') display.value += '√(';
  else if (value === 'Math.pow(') display.value += '^';
  else if (value === 'Math.PI') display.value += 'π';
  else display.value += value;

  autoCalculate();
}

function clearDisplay() {
  display.value = '';
  result.value = '';
}

function deleteLast() {
  display.value = display.value.slice(0, -1);
  autoCalculate();
}

function autoCalculate() {
  try {
    if (display.value.trim() === '') {
      result.value = '';
      return;
    }

    let expression = display.value;

    expression = expression
      .replace(/sin\(/g, 'Math.sin(')
      .replace(/cos\(/g, 'Math.cos(')
      .replace(/tan\(/g, 'Math.tan(')
      .replace(/log\(/g, 'Math.log10(')
      .replace(/√\(/g, 'Math.sqrt(')
      .replace(/π/g, 'Math.PI')
      .replace(/e/g, 'Math.E')
      .replace(/\^/g, '**')
      .replace(/(\d+(\.\d+)?)%/g, '($1/100)');

    const evaluated = eval(expression);
    result.value = evaluated;
  } catch {
    result.value = 'Syntax Error';
  }
}

document.addEventListener('keydown', (e) => {
  const key = e.key;
  if ((key >= '0' && key <= '9') || "+-*/().".includes(key)) {
    display.value += key;
    autoCalculate();
  } else if (key === 'Backspace') {
    deleteLast();
  } else if (key === 'Escape') {
    clearDisplay();
  }
});
